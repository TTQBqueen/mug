<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\CartController;

// ************************************************* PRODUCTS CONTROLLER ***************************************************

// ************** USER ***************
Route::get('/', ['uses' => '\App\Http\Controllers\ProductController@index']);
Route::get('/', ['uses' => '\App\Http\Controllers\ProductController@index'])->name('product');
Route::get('/product/{sku}', ['uses' => '\App\Http\Controllers\ProductController@get']);
Route::post('/product/add/{sku}', ['uses' => '\App\Http\Controllers\ProductController@cart']);

// ************** ADMIN ****************
Route::get('/admin/products', ['uses' => '\App\Http\Controllers\ProductController@admin_index']);
Route::post('/admin/products', ['uses' => '\App\Http\Controllers\ProductController@admin_new_product']);
Route::get('/product/delete/{sku}', ['uses' => '\App\Http\Controllers\ProductController@delete'])->name('product.delete');
Route::get('/product/edit/{sku}', ['uses' => '\App\Http\Controllers\ProductController@updateProduct'])->name('product.edit');
Route::post('/product/update/{sku}', ['uses' => '\App\Http\Controllers\ProductController@admin_edit_product'])->name('product.update');

// ************************************************* ORDER CONTROLLER ***************************************************
// ************** ADMIN ****************

Route::get('/admin/orders', [OrderController::class, 'adminOrderList'])->name('admin.orders');
Route::get('/admin/orders/{orderId}', [OrderController::class, 'adminOrderDetails'])->name('admin.order.details');

// ************************************************* CART CONTROLLER ***************************************************

// ************** CART ***************

Route::post('/cart/add/{sku}', [CartController::class, 'addToCart'])->name('cart.add');
Route::get('/cart', [CartController::class, 'viewCart'])->name('cart.view');
Route::get('/cart/remove/{sku}', [CartController::class, 'removeFromCart'])->name('cart.remove');
Route::post('/cart/update/{sku}', [CartController::class, 'updateQuantity'])->name('cart.update');


// ************** CHECKOUT ****************

// Order confirmation route
Route::get('/order/confirmation', [CartController::class, 'confirmation'])->name('confirmed_order');

// Checkout routes
Route::get('/checkout', [CartController::class, 'checkout'])->name('checkout');
Route::post('/checkout/process', [CartController::class, 'processCheckout'])->name('checkout.process');


