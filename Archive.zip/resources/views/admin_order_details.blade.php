@extends('app')

@section('content')
    <div class="container my-5">
        <div class="row">
            <h3 class="text-center mb-4">Order Details (Admin)</h3>
        </div>

        <div class="mb-3">
            <a href="{{ route('admin.orders') }}" class="btn btn-primary">Back to Orders List</a>
        </div>

        <!-- Order Information -->
        <h4>Order Summary</h4>
        <table class="table table-bordered table-hover table-sm">
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Email</th>
                    <th>Total Price</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ $order->id }}</td>
                    <td>{{ $order->name }}</td>
                    <td>{{ $order->email }}</td>
                    <td>${{ number_format($order->total_price, 2) }}</td>
                </tr>
            </tbody>
        </table>

        <!-- Order Items -->
        <h5>Order Items</h5>
        <table class="table table-striped table-sm">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($order->items as $item)
                    <tr>
                        <td>{{ $item->product_name }}</td>
                        <td>${{ number_format($item->price, 2) }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>${{ number_format($item->total, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Shipping Information -->
        <h5>Shipping Information</h5>
        <ul class="list-unstyled">
            <li><strong>Name:</strong> {{ $order->name }}</li>
            <li><strong>Email:</strong> {{ $order->email }}</li>
            <li><strong>Phone:</strong> {{ $order->phone }}</li>
            <li><strong>Address:</strong> {{ $order->address }}</li>
            <li><strong>City:</strong> {{ $order->city }}</li>
            <li><strong>State:</strong> {{ $order->state }}</li>
            <li><strong>Postal Code:</strong> {{ $order->zip }}</li>
        </ul>
    </div>
@endsection
