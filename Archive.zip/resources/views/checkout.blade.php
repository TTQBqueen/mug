@extends('app')

@section('content')
    <h1>Checkout</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @elseif(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    <h3>Your Order Summary</h3>
    <table class="table table-striped table-hover table-sm">
        <thead class="thead-dark">
            <tr class="d-flex">
                <th scope="col" class="col-3">Name</th>
                <th scope="col" class="col-2">Price</th>
                <th scope="col" class="col-2">Quantity</th>
                <th scope="col" class="col-2">Total</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($cart as $sku => $item)
                <tr class="d-flex">
                    <td class="col-3">{{ $item['name'] }}</td>
                    <td class="col-2">${{ number_format($item['price'], 2) }}</td>
                    <td class="col-2">{{ $item['quantity'] }}</td>
                    <td class="col-2">${{ number_format($item['price'] * $item['quantity'], 2) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Grand Total Calculation -->
    <div class="d-flex justify-content-end">
        <h4>Grand Total: ${{ number_format(array_sum(array_map(function ($item) {
            return $item['price'] * $item['quantity'];
        }, $cart)), 2) }}</h4>
    </div>

    <!-- Shipping Information Form -->
    <h3>Shipping Information</h3>
    <form action="{{ route('checkout.process') }}" method="POST">
        @csrf

        <!-- Personal Information Section -->
        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="name">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="email">Email Address</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="phone">Phone Number</label>
                <input type="text" class="form-control" id="phone" name="phone" required>
            </div>
        </div>

        <!-- Shipping Information Section -->
        <div class="row">
            <div class="col-md-12 mb-3">
                <label for="address">Shipping Address</label>
                <input type="text" class="form-control" id="address" name="address" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="city">City</label>
                <input type="text" class="form-control" id="city" name="city" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="state">State</label>
                <input type="text" class="form-control" id="state" name="state" required>
            </div>
            <div class="col-md-6 mb-3">
                <label for="zip">Postal Code</label>
                <input type="text" class="form-control" id="zip" name="zip" required>
            </div>
        </div>

        <!-- Confirm Order Button -->
        <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-success">Confirm Order</button>
        </div>
    </form>

@endsection
