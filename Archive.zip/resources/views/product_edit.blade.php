@extends('app')

@section('content')

<div class="container my-5">
    <h3 class="text-center mb-4">Edit Product</h3>

    <form action="{{ route('product.update', ['sku' => $product->sku]) }}" method="POST">
        @csrf
        <div class="row">

            <!-- SKU (Readonly) -->
            <div class="col-md-4 mb-3">
                <label for="sku">SKU</label>
                <input type="text" class="form-control" id="sku" name="sku" value="{{ $product->sku }}" readonly>
            </div>

            <!-- Product Name -->
            <div class="col-md-4 mb-3">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="{{ $product->name }}" required>
            </div>

            <!-- Product Description -->
            <div class="col-md-4 mb-3">
                <label for="description">Description</label>
                <input type="text" class="form-control" id="description" name="description" value="{{ $product->description }}" required>
            </div>

            <!-- Product Price -->
            <div class="col-md-4 mb-3">
                <label for="price">Price</label>
                <input type="number" min="1" step="0.01" class="form-control" id="price" name="price" value="{{ $product->price }}" required>
            </div>

            <!-- Product Image URL -->
            <div class="col-md-4 mb-3">
                <label for="image_url">Image URL</label>
                <input type="url" class="form-control" id="image_url" name="image_url" value="{{ $product->image_url }}" required>
            </div>

            <!-- Product Capacity -->
            <div class="col-md-4 mb-3">
                <label for="capacity">Capacity (oz.)</label>
                <input type="number" min="1" step="1" class="form-control" id="capacity" name="capacity" value="{{ $product->capacity }}" required>
            </div>

            <!-- Product Dimensions -->
            <div class="col-md-4 mb-3">
                <label for="dimension">Dimension (LxWxH)</label>
                <input type="text" class="form-control" id="dimension" name="dimension" value="{{ $product->dimension }}" required>
            </div>

            <!-- Product Quantity -->
            <div class="col-md-4 mb-3">
                <label for="quantity">Quantity</label>
                <input type="number" min="1" step="1" class="form-control" id="quantity" name="quantity" value="{{ $product->quantity }}" required>
            </div>

            <!-- Dishwasher Safe -->
            <div class="col-md-4 mb-3">
                <label>Dishwasher Safe</label><br>
                <div class="form-check form-check-inline">
                    <input type="radio" class="form-check-input" id="dishwasher_safe_yes" name="dishwasher_safe" value="1" {{ $product->dishwasher_safe == 1 ? 'checked' : '' }} required>
                    <label class="form-check-label" for="dishwasher_safe_yes">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" class="form-check-input" id="dishwasher_safe_no" name="dishwasher_safe" value="0" {{ $product->dishwasher_safe == 0 ? 'checked' : '' }} required>
                    <label class="form-check-label" for="dishwasher_safe_no">No</label>
                </div>
            </div>

            <!-- Microwave Safe -->
            <div class="col-md-4 mb-3">
                <label>Microwave Safe</label><br>
                <div class="form-check form-check-inline">
                    <input type="radio" class="form-check-input" id="microwave_safe_yes" name="microwave_safe" value="1" {{ $product->microwave_safe == 1 ? 'checked' : '' }} required>
                    <label class="form-check-label" for="microwave_safe_yes">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" class="form-check-input" id="microwave_safe_no" name="microwave_safe" value="0" {{ $product->microwave_safe == 0 ? 'checked' : '' }} required>
                    <label class="form-check-label" for="microwave_safe_no">No</label>
                </div>
            </div>

        </div>

        <!-- Update Button -->
        <div class="text-center mt-4">
            <button type="submit" class="btn btn-success btn-lg">Update Product</button>
        </div>
    </form>
</div>

@endsection
