@extends('app')

@section('content')
    <h1 class="text-center my-4">Products Page</h1>

    <!-- Cart Button -->
    <div class="cart-button mb-3 text-center">
        <a href="{{ route('cart.view') }}">
            <button class="btn btn-primary">Go to Cart <span class="badge badge-light">{{ count(session('cart', [])) }}</span></button>
        </a>
    </div>

    <!-- Product Listing -->
    <div class="container">
        <div class="row">
            @foreach ($rs as $row)
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <img src="{{ $row->image_url }}" class="card-img" alt="{{ $row->name }}">
                        <div class="card-body">
                            <h5 class="card-title">{{ $row->name }}</h5>
                            <p class="card-text">{{ Str::limit($row->description, 100) }}</p>
                            <p class="card-text"><strong>Price:</strong> ${{ number_format($row->price, 2) }}</p>
                            <p class="card-text"><strong>Capacity:</strong> {{ $row->capacity }}oz</p>
                            <p class="card-text"><strong>Dishwasher Safe:</strong> {{ $row->dishwasher_safe ? 'Yes' : 'No' }}</p>
                            <p class="card-text"><strong>Microwave Safe:</strong> {{ $row->microwave_safe ? 'Yes' : 'No' }}</p>
                            <p class="col-3"><a href="/product/{{$row->sku}}">More Info</a></p>
                        </div>
                        <div class="card-footer text-center">
                            <!-- Add to Cart Form -->
                            <form action="{{ route('cart.add', ['sku' => $row->sku]) }}" method="POST">
                                @csrf
                                <button type="submit" class="btn btn-primary btn-block">Add to Cart</button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
