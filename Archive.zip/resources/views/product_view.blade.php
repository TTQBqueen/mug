@extends('app')

@section('content')

<div class="container my-4">
    <h3 class="text-center mb-4">Product Details</h3>

    <!-- Cart Button and Continue Shopping Button -->
    <div class="d-flex justify-content-between mb-3">
        <div class="cart-button">
            <a href="{{ route('cart.view') }}">
                <button class="btn btn-primary">
                    Cart 
                    <span class="badge badge-light">{{ count(session('cart', [])) }}</span>
                </button>
            </a>
        </div>
        <div>
            <a href="{{ route('product') }}" class="btn btn-secondary">Continue Shopping</a>
        </div>
    </div>

    <!-- Product Details Card -->
    <div class="card">
        <div class="row no-gutters">
            <!-- Product Image -->
            <div class="col-md-4">
                <img src="{{ $product_view->image_url }}" class="card-img" alt="{{ $product_view->name }}">
            </div>

            <!-- Product Information -->
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title">{{ $product_view->name }}</h5>
                    <p class="card-text">{{ $product_view->description }}</p>

                    <p class="card-text"><strong>Price:</strong> ${{ number_format($product_view->price, 2) }}</p>
                    <p class="card-text"><strong>Capacity:</strong> {{ $product_view->capacity }}oz</p>
                    <p class="card-text"><strong>Dimensions:</strong> {{ $product_view->dimension }}</p>
                    <p class="card-text"><strong>Quantity:</strong> {{ $product_view->quantity }}</p>
                    <p class="card-text"><strong>Dishwasher Safe:</strong> {{ $product_view->dishwasher_safe ? 'Yes' : 'No' }}</p>
                    <p class="card-text"><strong>Microwave Safe:</strong> {{ $product_view->microwave_safe ? 'Yes' : 'No' }}</p>

                    <!-- Add to Cart Button -->
                    <form action="{{ route('cart.add', ['sku' => $product_view->sku]) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-success btn-lg btn-block">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

@endsection
