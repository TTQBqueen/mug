@extends('app')

@section('content')
    <div class="container my-5">
        <div class="row">
            <h3 class="text-center mb-4">Manage Orders (Admin)</h3>
        </div>

        <!-- Back to Products Button -->
        <div class="mb-3">
            <a href="{{ route('product') }}" class="btn btn-primary">Back to Products</a>
        </div>

        <!-- Orders Listing Table -->
        <h4 class="mb-3">Orders List</h4>
        <table class="table table-striped table-hover table-sm">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Order ID</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Total Price</th>
                    <th scope="col" class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($orders as $order)
                    <tr>
                        <td>{{ $order->id }}</td>
                        <td>{{ $order->name }}</td>
                        <td>${{ number_format($order->total_price, 2) }}</td>
                        <td class="text-center">
                            <a href="{{ route('admin.order.details', ['orderId' => $order->id]) }}" class="btn btn-info btn-sm">View Details</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="text-center">No orders found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
@endsection
