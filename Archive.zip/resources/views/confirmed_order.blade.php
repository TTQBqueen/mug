@extends('app')

@section('content')
<style>
    /* Custom Styling for Order Confirmation Page */
.table th, .table td {
    padding: 1rem;
}

.card ul {
    padding-left: 0;
}

.card li {
    margin-bottom: 0.5rem;
}
</style>
    <div class="container my-5">
        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success text-center">
                <h4>{{ session('success') }}</h4>
            </div>
        @endif

        <div class="text-center mb-4">
            <h1>Order Confirmed</h1>
            <p class="lead">Thank you for your order! Here is a summary of your purchase.</p>
        </div>

        <!-- Order Summary Table -->
        <h3>Your Order Summary</h3>
        <table class="table table-striped table-bordered table-hover table-sm mt-3">
            <thead class="thead-dark">
                <tr>
                    <th scope="col" class="text-center">Product Name</th>
                    <th scope="col" class="text-center">Price</th>
                    <th scope="col" class="text-center">Quantity</th>
                    <th scope="col" class="text-center">Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($order->items as $item)
                    <tr>
                        <td class="text-center">{{ $item->product_name }}</td>
                        <td class="text-center">${{ number_format($item->price, 2) }}</td>
                        <td class="text-center">{{ $item->quantity }}</td>
                        <td class="text-center">${{ number_format($item->total, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="d-flex justify-content-end mt-3">
            <h4><strong>Grand Total: ${{ number_format($order->total_price, 2) }}</strong></h4>
        </div>

        <!-- Shipping Information -->
        <h3 class="mt-5">Shipping Information</h3>
        <div class="card shadow-sm p-4">
            <ul class="list-unstyled">
                <li><strong>Name:</strong> {{ $order->name }}</li>
                <li><strong>Email:</strong> {{ $order->email }}</li>
                <li><strong>Phone:</strong> {{ $order->phone }}</li>
                <li><strong>Address:</strong> {{ $order->address }}</li>
                <li><strong>City:</strong> {{ $order->city }}</li>
                <li><strong>State:</strong> {{ $order->state }}</li>
                <li><strong>Postal Code:</strong> {{ $order->zip }}</li>
            </ul>
        </div>

        <div class="d-flex justify-content-end mt-4">
            <a href="{{ route('product') }}" class="btn btn-primary btn-lg">Back to Home</a>
        </div>
    </div>
@endsection
