@extends('app')

@section('content')
    <h1>Your Cart</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @elseif(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    @if(count($cart) > 0)
        <table class="table table-striped table-hover table-sm">
            <thead class="thead-dark">
                <tr class="d-flex">
                    <th scope="col" class="col-3">Name</th>
                    <th scope="col" class="col-2">Price</th>
                    <th scope="col" class="col-2">Quantity</th>
                    <th scope="col" class="col-2">Total</th>
                    <th scope="col" class="col-2">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($cart as $sku => $item)
                    <tr class="d-flex">
                        <td class="col-3">{{ $item['name'] }}</td>
                        <td class="col-2">${{ number_format($item['price'], 2) }}</td>
                        <td class="col-2">
                            <form action="{{ route('cart.update', ['sku' => $sku]) }}" method="POST" class="d-flex">
                                @csrf
                                <button type="submit" name="action" value="decrease" class="btn btn-sm btn-secondary">-</button>
                                <input type="number" value="{{ $item['quantity'] }}" class="form-control mx-2" style="width: 60px;" disabled>
                                <button type="submit" name="action" value="increase" class="btn btn-sm btn-secondary">+</button>
                            </form>
                        </td>
                        <td class="col-2">${{ number_format($item['price'] * $item['quantity'], 2) }}</td>
                        <td class="col-2">
                            <a href="{{ route('cart.remove', ['sku' => $sku]) }}" class="btn btn-danger btn-sm">Remove</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <a href="{{ route('product') }}" class="btn btn-primary">Continue Shopping</a>
        <!-- Grand Total Calculation -->
        <div class="d-flex justify-content-end">
            <h4>Grand Total: ${{ number_format(array_sum(array_map(function ($item) {
                return $item['price'] * $item['quantity'];
            }, $cart)), 2) }}</h4>
        </div>

        <!-- Checkout Button -->
        <div class="d-flex justify-content-end">
            <a href="{{ route('checkout') }}" class="btn btn-success">Proceed to Checkout</a>
        </div>

    @else
        <p>Your cart is empty.</p>
        <a href="{{ route('product') }}" class="btn btn-primary">Continue Shopping</a>
    @endif
@endsection
