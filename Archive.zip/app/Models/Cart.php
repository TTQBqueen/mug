<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;

class Cart
{
public static function getCartByCartId($cartId)
{
    $params = [
        $cartId
    ];

    $sql = "SELECT * FROM cart WHERE cart_id = ? AND deleted = false";

    try {
        $rs = DB::select($sql, $params);
        return $rs;
    } catch (\Illuminate\Database\QueryException $p) {
        return [];
    }
}

    // Create cart for a session
    public static function createCartForSession($cartId)
    {
        $params = [
            $cartId
        ];

        // Query to create a new cart
        $sql = "INSERT INTO cart (cart_id, created_at, updated_at) VALUES (?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";

        try {
            DB::insert($sql, $params);
            return true;
        } catch (\Illuminate\Database\QueryException $p) {
            return false;
        }
    }
}
