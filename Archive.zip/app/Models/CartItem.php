<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;

class CartItem
{
    // Add an item to the cart
    public static function addItem($cartId, $sku, $quantity, $price)
    {
        $params = [
            $cartId,
            $sku,
            $quantity,
            $price
        ];

        // Insert query to add an item to the cart
        $sql = "INSERT INTO cart_item (cart_id, sku, quantity, price, created_at, updated_at)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";

        try {
            DB::insert($sql, $params);
            return true;
        } catch (\Illuminate\Database\QueryException $p) {
            return false;
        }
    }

    // Get items in the cart based on cart_id
    public static function getItemsByCartId($cartId)
    {
        $params = [
            $cartId
        ];

        // Query to fetch cart items based on cart_id
        $sql = "SELECT ci.cart_item_id, ci.sku, ci.quantity, ci.price, p.name 
                FROM cart_item ci
                JOIN products p ON ci.sku = p.sku
                WHERE ci.cart_id = ? AND ci.deleted = false";

        try {
            $rs = DB::select($sql, $params);
        } catch (\Illuminate\Database\QueryException $p) {
            $rs = [];
        }

        return $rs;
    }

    // Remove an item from the cart
    public static function removeItem($cartItemId)
    {
        $params = [
            $cartItemId
        ];

        // Soft delete the item from the cart by setting `deleted = true`
        $sql = "UPDATE cart_item 
                SET deleted = true, updated_at = CURRENT_TIMESTAMP
                WHERE cart_item_id = ?";

        try {
            DB::update($sql, $params);
            return true;
        } catch (\Illuminate\Database\QueryException $p) {
            return false;
        }
    }
}
