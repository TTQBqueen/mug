<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;



class Products 
{

    public static function all($show_deleted = false)
    {
        $sql = "SELECT p.sku, p.name, p.description, p.price, p.image_url, p.capacity, p.dimension, p.quantity, p.dishwasher_safe, p.microwave_safe
                FROM products p";
        if ($show_deleted == false) {
            $sql .= " WHERE deleted = false";
        }
        $sql .= " GROUP BY p.sku, p.name, p.description, p.price";
        try {
            $rs = DB::select($sql);
        } catch (\Illuminate\Database\QueryException $p) {
            $rs = [];
        }
        return $rs;
    }


    public static function add($sku, $name, $description, $price, $image_url, $capacity, $dimension, $quantity, $dishwasher_safe, $microwave_safe)
{
    $params = [
        $sku,
        $name,
        $description,
        $price,
        $image_url,
        $capacity,
        $dimension,
        $quantity,
        $dishwasher_safe,
        $microwave_safe
    ];

    $sql = "INSERT INTO products (sku, name, description, price, image_url, capacity, dimension, quantity, dishwasher_safe, microwave_safe, createdat, updatedat, deleted)
            VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, false)";

    try {
        DB::insert($sql, $params);
        return true;
    } catch (\Illuminate\Database\QueryException $p) {
        return false;
    }
}



    // update a product's information
    public static function updateProduct($sku, $name, $description, $price, $image_url, $capacity, $dimension, $quantity, $dishwasher_safe, $microwave_safe)
    {
        $params = [
            $name, $description, $price, $image_url, $capacity, $dimension,
            $quantity, $dishwasher_safe, $microwave_safe, $sku
        ];

        $sql = "UPDATE products 
                SET name = ?, description = ?, price = ?, image_url = ?, capacity = ?, dimension = ?, 
                    quantity = ?, dishwasher_safe = ?, microwave_safe = ?
                WHERE sku = ?";

        try {
            DB::update($sql, $params);
            return true;
        } catch (\Illuminate\Database\QueryException $e) {
            return false;
        }
    }



    public static function delete($sku)
    {
        $params = [
            $sku
        ];
        $sql = "UPDATE products
SET deleted = true
WHERE sku = ?";
        try {
            DB::update($sql, $params);
            $rs = true;
        } catch (\Illuminate\Database\QueryException $p) {
            $rs = false;
        }
        return $rs;
    }


    public static function get($sku)
{
    $params = [
        $sku
    ];

    $sql = "SELECT * FROM products WHERE sku = ?";

    try {
        $rs = DB::select($sql, $params);
        return $rs;
    } catch (\Illuminate\Database\QueryException $p) {
        return [];
    }
}

}
