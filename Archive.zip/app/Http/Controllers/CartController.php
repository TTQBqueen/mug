<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;
use App\Models\Order;
use App\Models\OrderItem;

class CartController extends Controller
{
    // Add product to cart
    public function addToCart(Request $request, $sku)
    {
        $product = Products::get($sku);

        if (empty($product)) {
            return redirect()->back()->with('error', 'Product not found.');
        }
        $cart = session()->get('cart', []);

        if (isset($cart[$sku])) {
            $cart[$sku]['quantity']++;
        } else {
            $cart[$sku] = [
                'name' => $product[0]->name,
                'price' => $product[0]->price,
                'quantity' => 1,
            ];
        }
        session()->put('cart', $cart);

        return redirect()->route('cart.view')->with('success', 'Product added to cart.');
    }

    // View the cart
    public function viewCart(Request $request)
    {

        $cart = session()->get('cart', []);

        return view('cart_index', compact('cart'));
    }

    // Remove item from cart
    public function removeFromCart(Request $request, $sku)
    {

        $cart = session()->get('cart', []);


        if (isset($cart[$sku])) {

            unset($cart[$sku]);

            session()->put('cart', $cart);
        }

        return redirect()->route('cart.view')->with('success', 'Product removed from cart.');
    }

    // Update item quantity (increase or decrease)
    public function updateQuantity(Request $request, $sku)
    {
        //increase or decrease
        $action = $request->input('action');


        $cart = session()->get('cart', []);


        if (isset($cart[$sku])) {

            if ($action == 'increase') {
                $cart[$sku]['quantity']++;
            } elseif ($action == 'decrease' && $cart[$sku]['quantity'] > 1) {
                $cart[$sku]['quantity']--;
            }

            session()->put('cart', $cart);
        }

        return redirect()->route('cart.view');
    }



    // checkout, processCheckout, and confirmation methods

    public function checkout(Request $request)
    {

        $cart = session()->get('cart', []);

        if (empty($cart)) {
            return redirect()->route('cart.view')->with('error', 'Your cart is empty.');
        }


        return view('checkout', compact('cart'));
    }


    public function processCheckout(Request $request)
    {

        $cart = session()->get('cart', []);
        $shippingInfo = $request->only(['name', 'email', 'phone', 'address', 'city', 'state', 'zip']);


        if (empty($cart)) {
            return redirect()->route('cart.view')->with('error', 'Your cart is empty.');
        }

        // Calculate total price
        $totalPrice = array_sum(array_map(function ($item) {
            return $item['price'] * $item['quantity'];
        }, $cart));
        // Create a new order
        $order = Order::create([
            'name' => $shippingInfo['name'],
            'email' => $shippingInfo['email'],
            'phone' => $shippingInfo['phone'],
            'address' => $shippingInfo['address'],
            'city' => $shippingInfo['city'],
            'state' => $shippingInfo['state'],
            'zip' => $shippingInfo['zip'],
            'total_price' => $totalPrice
        ]);

        foreach ($cart as $sku => $item) {
            $order->items()->create([
                'product_name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $item['quantity'],
                'total' => $item['price'] * $item['quantity']
            ]);
        }

        // Clear the cart 
        session()->forget('cart');

        return redirect()->route('confirmed_order')->with('success', 'Your order has been placed successfully.');
    }

    public function confirmation(Request $request)
    {
        // Get the order by the ID 
        $order = Order::with('items')->latest()->first();

        if (!$order) {
            return redirect()->route('cart.view')->with('error', 'Order not found.');
        }

        return view('confirmed_order', compact('order'));
    }
}
