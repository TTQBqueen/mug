<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products;

class ProductController extends Controller
{
    public function index(Request $request)
    {

        return view('products', ['rs' => \App\Models\Products::all()]);
    }



    public function admin_index(Request $request)
    {

        return view('admin', ['rs' => \App\Models\Products::all()]);
    }


    public function admin_new_product(Request $request)
    {
        $sku = $request['sku'];
        $name = $request['name'];
        $description = $request['description'];
        $price = $request['price'];
        $image_url = $request['image_url'];
        $capacity = $request['capacity'];
        $dimension = $request['dimension'];
        $quantity = $request['quantity'];
        $dishwasher_safe = $request['dishwasher_safe'];
        $microwave_safe = $request['microwave_safe'];


        \App\Models\Products::add($sku, $name, $description, $price, $image_url, $capacity, $dimension, $quantity, $dishwasher_safe, $microwave_safe);

        return view('admin', ['rs' => \App\Models\Products::all()]);
    }


    public function get(Request $request, $sku)
    {
      
        return view('product_view', ['product_view' => \App\Models\Products::get($sku)[0]]);
    }

    

    public function delete($sku)
    {

        $result = Products::delete($sku);

        if ($result) {
            
            return redirect('/admin/products')->with('success', 'Product marked as deleted.');
        } else {
           
            return redirect('/admin/products')->with('success', 'Product marked as deleted.');
        }
    }


    public function admin_edit_product(Request $request, $sku)
    {
        // Retrieve the product by its SKU
        $product = \App\Models\Products::get($sku)[0];
    
        if (!$product) {
            return redirect('/admin/products')->with('error', 'Product not found.');
        }
    
        // Retrieve the updated product details from the form
        $name = $request['name'];
        $description = $request['description'];
        $price = $request['price'];
        $image_url = $request['image_url'];
        $capacity = $request['capacity'];
        $dimension = $request['dimension'];
        $quantity = $request['quantity'];
        $dishwasher_safe = $request['dishwasher_safe'];
        $microwave_safe = $request['microwave_safe'];
    
        // Call the updateProduct method to update the product
        $result = \App\Models\Products::updateProduct(
            $sku, 
            $name, 
            $description, 
            $price, 
            $image_url, 
            $capacity, 
            $dimension, 
            $quantity, 
            $dishwasher_safe, 
            $microwave_safe
        );
    
        if ($result) {
            return redirect('/admin/products')->with('success', 'Product updated successfully.');
        } else {
            return redirect('/admin/products')->with('error', 'Failed to update product.');
        }
    }
    
// Show the edit form for a product
public function updateProduct($sku)
{
  
    $product = \App\Models\Products::get($sku)[0];

    if (!$product) {
        return redirect()->route('admin.products')->with('error', 'Product not found.');
    }

    return view('product_edit', compact('product'));
}
    

    
}