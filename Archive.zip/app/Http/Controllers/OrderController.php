<?php
namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    // Display all orders
    public function adminOrderList()
    {
       
        $orders = Order::all();

       
        return view('admin_order', compact('orders'));
    }

    // Show the details of a specific order
    public function adminOrderDetails($orderId)
    {
        // Find the order by ID
        $order = Order::with('items')->find($orderId);

        
        if (!$order) {
            return redirect()->route('admin.orders')->with('error', 'Order not found.');
        }

    
        return view('admin_order_details', compact('order'));
    }
}
